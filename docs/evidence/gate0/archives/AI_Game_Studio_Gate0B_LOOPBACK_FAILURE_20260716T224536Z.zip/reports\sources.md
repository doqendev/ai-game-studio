# Official sources

- OpenAI Windows sandbox: https://learn.chatgpt.com/docs/windows/windows-sandbox
- OpenAI Codex firewall implementation: https://github.com/openai/codex/blob/main/codex-rs/windows-sandbox-rs/src/firewall.rs
- Microsoft WFP filtering condition flags: https://learn.microsoft.com/en-us/windows/win32/fwp/filtering-condition-flags-
- Microsoft Application Layer Enforcement: https://learn.microsoft.com/en-us/windows/win32/fwp/application-layer-enforcement--ale-
- Microsoft New-NetFirewallRule: https://learn.microsoft.com/en-us/powershell/module/netsecurity/new-netfirewallrule