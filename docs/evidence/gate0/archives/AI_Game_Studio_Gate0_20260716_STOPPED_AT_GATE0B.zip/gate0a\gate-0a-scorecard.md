# Gate 0A scorecard

**Decision: GO to Gate 0B only. Product implementation and Milestone 1 remain blocked.**

Completed: 2026-07-16T21:41:15.7804140Z

## Hard-gate results

| Probe | Result |
|---|---|
| A-PROTO-01 - exact binary version and SHA-256 pin succeeds | PASS |
| A-PROTO-02 - mismatched global Codex is rejected before App Server launch | PASS |
| A-PROTO-03 - initialize handshake reports exact isolated CODEX_HOME | PASS |
| A-PROTO-04 - request before initialize fails closed | PASS |
| A-PROTO-05 - unknown server method returns an explicit RPC error | PASS |
| A-PROTO-06 - adapter blocks a real but non-allowlisted App Server method | PASS |
| A-PROTO-07 - oversized App Server frame terminates the supervised fixture | PASS |
| A-PROTO-08 - sustained App Server event flooding terminates the supervised fixture | PASS |
| A-PROTO-09 - unresponsive App Server request times out without replay | PASS |
| A-AUTH-01 - fresh managed CODEX_HOME has user-only ACL and global auth baseline is recorded | PASS |
| A-AUTH-02 - fresh App Server account is empty and device-code login can be canceled | PASS |
| A-AUTH-03 - browser ChatGPT login completes inside only the managed CODEX_HOME | PASS |
| A-AUTH-04 - App Server restart preserves only the isolated login | PASS |
| A-AUTH-05 - isolated logout clears the managed account and leaves global login unchanged | PASS |
| A-PROC-01 - killing an unsupervised parent does not reliably kill descendants | PASS |
| A-PROC-02 - closing the Job Object supervisor kills the full descendant tree | PASS |
| A-PROC-03 - owner-process death is detected and kills the supervised tree | PASS |
| A-PROC-04 - infinite high-CPU process is killed by the wall-clock limit | PASS |
| A-PROC-05 - aggregate process-tree memory growth triggers termination before the hard cap | PASS |
| A-PROC-06 - real App Server can spawn a controlled child inside the outer Job Object and cleanup kills it | PASS |

## Confirmed on this machine

- Codex 0.144.5 was pinned by exact version and SHA-256; global Codex 0.143.0 was rejected before launch.
- Stable generated output was requested without `--experimental`: 598 TypeScript files and 266 individual JSON schemas repeated byte-for-byte. The aggregate schema bundle is semantically equal after canonical object-key ordering, but its definition order is nondeterministic.
- The actual stdio App Server initialized through the Job Object helper and reported the exact isolated `CODEX_HOME`. Pre-initialize and unknown requests failed explicitly; the adapter blocked `command/exec` outside a dedicated internal probe.
- Device-code login could be started and canceled. Browser ChatGPT login completed in a fresh file-backed managed home, survived App Server restart, logged out, removed the isolated credential file, and left the pre-existing global ChatGPT login unchanged.
- Detached descendants survived ordinary parent termination, but Job Object close and owner-process death removed the full tree. A real App Server child was also removed.
- Infinite CPU was terminated by duration. Aggregate memory growth terminated at 115,277,824 bytes under a 134,217,728-byte declared test limit, using an 80% high-water response and 90% OS hard cap.
- Oversized frames, sustained event flooding, and unresponsive requests terminated or timed out without replay.

## Corrections retained as evidence

- The first schema probe incorrectly required byte-stable aggregate object-key ordering; its failed packet is retained.
- Two flood fixtures undershot the declared rate because of Windows timer granularity; both failed attempts are retained. The final full-window test exceeded 1,250 events over five seconds and passed containment.
- The first two process baselines omitted the documented Windows detached-process condition; both failed attempts are retained.
- The initial authentication ACL ordering made its own config unreadable before authentication began. That home and report are retained; the corrected empty-directory-first ACL flow passed.
- The first memory calibration terminated correctly but sampled above the declared test ceiling. Its report is retained; the margin-corrected probe remained below the declared ceiling.

## Residual risks and hypotheses

- The `app-server` command and schema generators are still labeled experimental by the pinned CLI even though stable output was generated without the experimental flag. Automatic upgrades remain prohibited.
- The aggregate JSON Schema bundle has nondeterministic definition ordering. Consumers must use individual schemas or canonical semantic comparison, not bundle byte hashes across regeneration.
- Authentication was proven for this consumer ChatGPT account and Windows profile, not enterprise credential policies, roaming profiles, or offline sign-in.
- The Job Object mechanism was tested at a 128 MiB hostile limit and with the real App Server. Product-specific 2 GiB tuning remains a later implementation value, not a claim that every workload fits it.
- Gate 0A does not prove Builder sandbox containment, snapshots, crash-state recovery, Godot containment, or a review runtime. Those are Gate 0B/0C.

## Official sources used

- OpenAI Codex App Server: https://learn.chatgpt.com/docs/app-server
- OpenAI authentication and credential storage: https://learn.chatgpt.com/docs/auth#credential-storage
- OpenAI config/state locations: https://learn.chatgpt.com/docs/config-file/config-advanced#config-and-state-locations
- Microsoft Job Objects: https://learn.microsoft.com/en-us/windows/win32/procthread/job-objects
- Microsoft extended Job Object limits: https://learn.microsoft.com/en-us/windows/win32/api/winnt/ns-winnt-jobobject_extended_limit_information
- Node child-process detached behavior: https://nodejs.org/api/child_process.html#optionsdetached

## Stage decision

Gate 0A passes. Proceed to Gate 0B with the same pinned binary, schema bundle, managed authentication home pattern, output/event caps, and no-daemon Job Object helper. This is not authorization for Gate 0C, product UI, MVP role orchestration, or Milestone 1.
